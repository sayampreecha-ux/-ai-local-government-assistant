# แผนย้ายระบบเดิม v1.2 ไปสู่ SLDP v2.0

## สิ่งที่เก็บไว้
- แบบฟอร์มร่างหนังสือ
- Draft และ Autosave
- Export / Import
- รูปแบบ UI ที่ผู้ใช้คุ้นเคย

## สิ่งที่ต้องเปลี่ยน
- localStorage → Backend + PostgreSQL
- ผู้ใช้คนเดียว → Login และสิทธิ์
- เอกสารในเครื่อง → Object Storage
- AI จำลอง/ฝั่งหน้าเว็บ → AI Service ฝั่ง Server
- ข้อมูลไม่แยกองค์กร → Multi-tenant

## ลำดับย้าย
1. เก็บต้นแบบเดิมไว้ใน `legacy/prototype-v1.2`
2. สร้าง schema และ authentication
3. ย้าย Draft เป็น API
4. ย้าย Document Generator
5. เชื่อม AI ผ่าน Backend
6. เพิ่ม Document Center และ Law Center
