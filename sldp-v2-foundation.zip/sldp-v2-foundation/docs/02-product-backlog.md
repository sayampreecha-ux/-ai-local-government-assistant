# Product Backlog v1.0

## Sprint 1 — Foundation (ลำดับ P0)
- ตั้งโครงสร้าง repository
- ออกแบบ tenant boundary
- สร้าง organizations, users, roles, permissions
- Login/logout และ session
- Audit log middleware
- Environment configuration
- CI checks: lint, test, build

### Definition of Done
- ผู้ใช้เข้าสู่ระบบได้
- ผู้ใช้เห็นเฉพาะข้อมูลของหน่วยงานตนเอง
- ทุกการแก้ไขข้อมูลสำคัญมี audit record
- ไม่มี secret อยู่ใน browser bundle

## Sprint 2 — Smart Local AI (P0)
- สร้าง conversation และ message
- สร้าง prompt template สำหรับหนังสือราชการ
- บันทึก draft จากคำตอบ AI
- แสดง citation เมื่อใช้ฐานความรู้
- จำกัดสิทธิ์และโควตาต่อองค์กร

## Sprint 3 — Document Center (P0)
- Upload PDF/DOCX
- Metadata, tag, status, version
- Search และ filter
- Permission ระดับเอกสาร
- สรุปเอกสารด้วย AI

## Sprint 4 — Law Center & Dashboard (P1)
- นำเข้ากฎหมาย/ระเบียบพร้อม metadata
- ค้นหาแบบ keyword และ semantic
- แสดงมาตรา/หน้า/แหล่งอ้างอิง
- Dashboard งานค้างและกิจกรรมล่าสุด

## ยังไม่ทำใน MVP
- ระบบบัญชีเต็มรูปแบบ
- ระบบ e-GP/GFMIS ทดแทน
- ลายเซ็นดิจิทัลโดยไม่มีผู้ให้บริการที่ได้รับอนุญาต
- ระบบบุคลากรและงบประมาณเต็มชุด
