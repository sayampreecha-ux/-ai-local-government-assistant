# System Architecture v1.0

## 1. ภาพรวม
SLDP ใช้สถาปัตยกรรมแบบ Modular Monolith ใน MVP เพื่อให้พัฒนาเร็ว แต่กำหนดขอบเขตโมดูลชัดเจนเพื่อแยกเป็นบริการในอนาคตได้

## 2. องค์ประกอบ

```text
ผู้ใช้
  ↓ HTTPS
Frontend (Next.js)
  ↓ REST API
Backend Application
  ├─ Authentication & RBAC
  ├─ Organization / Tenant
  ├─ AI Workspace
  ├─ Document Center
  ├─ Law Center
  ├─ Dashboard
  ├─ Notification
  └─ Audit Log
  ↓                 ↓
PostgreSQL       Object Storage
  ↓
AI Orchestrator → LLM Provider
  ↓
Vector Search / Knowledge Base
```

## 3. ขอบเขตความปลอดภัย
- ทุกข้อมูลธุรกิจต้องมี `organization_id`
- Backend ตรวจสอบ Tenant และสิทธิ์ทุกคำขอ
- เอกสารใช้ URL แบบลงนามและหมดอายุ
- เก็บ Audit Log สำหรับการดู แก้ไข ดาวน์โหลด และลบข้อมูลสำคัญ
- Secret และ API key อยู่ฝั่ง Server เท่านั้น

## 4. โมดูล MVP
### Identity & Access
Login, logout, user, role, permission, organization membership

### Smart Local AI
Conversation, message, prompt template, citation, document context

### Document Center
Document metadata, version, attachment, tag, draft, status

### Law Center
Knowledge source, legal document, version, effective date, citation

### Executive Dashboard
งานค้าง เอกสารล่าสุด การใช้งาน และสรุปโดย AI ตามสิทธิ์

## 5. แนวทาง Deployment
- Development: Docker Compose
- Pilot: Managed PostgreSQL + S3-compatible storage + container hosting
- Production: แยก environment, backup, monitoring, WAF และ disaster recovery
