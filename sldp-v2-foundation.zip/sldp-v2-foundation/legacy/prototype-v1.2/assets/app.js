
const builtInPrompts = [
 {id:1,category:"หนังสือราชการ",title:"ร่างบันทึกข้อความเสนอผู้บริหาร",desc:"จัดทำบันทึกข้อความโดยแยกส่วนราชการ เรื่อง เรียน ข้อเท็จจริง ข้อกฎหมาย และข้อเสนอ",text:"คุณเป็นเจ้าหน้าที่ธุรการขององค์กรปกครองส่วนท้องถิ่น โปรดร่างบันทึกข้อความเรื่อง [เรื่อง] เรียน [ผู้รับ] โดยใช้ข้อมูลต่อไปนี้: [ข้อเท็จจริง] จัดโครงเป็น 1) ความเป็นมา 2) ข้อเท็จจริง 3) ระเบียบ/ข้อกฎหมายที่เกี่ยวข้อง 4) ข้อพิจารณา 5) ข้อเสนอเพื่อโปรดพิจารณา ใช้ภาษาราชการ กระชับ และไม่สร้างข้อกฎหมายที่ไม่มีข้อมูล"},
 {id:2,category:"การประชุม",title:"สรุปรายงานการประชุม",desc:"เปลี่ยนบันทึกการประชุมให้เป็นรายงานแบบเป็นทางการ พร้อมมติและผู้รับผิดชอบ",text:"โปรดสรุปบันทึกการประชุมต่อไปนี้เป็นรายงานการประชุมทางราชการ แยกผู้เข้าร่วม ระเบียบวาระ สาระสำคัญ มติ ผู้รับผิดชอบ และกำหนดเวลา: [วางบันทึก] ห้ามเติมข้อมูลที่ไม่ได้กล่าวถึง"},
 {id:3,category:"งบประมาณ",title:"วิเคราะห์คำของบประมาณ",desc:"ตรวจความครบถ้วนของเหตุผล ความจำเป็น ผลลัพธ์ และความเสี่ยง",text:"ในฐานะนักวิเคราะห์นโยบายและแผน โปรดตรวจคำของบประมาณโครงการ [ชื่อโครงการ] จากข้อมูล [รายละเอียด] โดยวิเคราะห์ปัญหา วัตถุประสงค์ กลุ่มเป้าหมาย ตัวชี้วัด ความคุ้มค่า ความเสี่ยง และรายการข้อมูลที่ยังขาด"},
 {id:4,category:"ประชาสัมพันธ์",title:"ข่าวประชาสัมพันธ์โครงการ",desc:"สร้างข่าวประชาสัมพันธ์ภาษาง่าย แต่ยังคงข้อมูลราชการที่จำเป็น",text:"เขียนข่าวประชาสัมพันธ์ของ [หน่วยงาน] เรื่อง [กิจกรรม] สำหรับประชาชนทั่วไป ระบุวันเวลา สถานที่ วัตถุประสงค์ ประโยชน์ ช่องทางติดต่อ และคำเชิญชวน ความยาวประมาณ 250-350 คำ"},
 {id:5,category:"กฎหมาย",title:"จัดประเด็นข้อเท็จจริงและข้อกฎหมาย",desc:"แยกข้อเท็จจริง ประเด็นกฎหมาย เอกสารที่ต้องตรวจ และความเสี่ยง",text:"โปรดช่วยจัดโครงวิเคราะห์เรื่อง [หัวข้อ] จากข้อเท็จจริง [ข้อเท็จจริง] แยกเป็น: ข้อเท็จจริงที่ยืนยันแล้ว, ข้อเท็จจริงที่ต้องตรวจเพิ่ม, ประเด็นกฎหมาย, กฎหมาย/ระเบียบที่ควรค้น, แนวทางดำเนินการ, ความเสี่ยง และคำถามสำหรับผู้มีอำนาจวินิจฉัย ห้ามสรุปเป็นข้อยุติหากข้อมูลไม่พอ"},
 {id:6,category:"จัดซื้อจัดจ้าง",title:"ตรวจ TOR เบื้องต้น",desc:"ตรวจความชัดเจน ความเป็นกลาง เกณฑ์ส่งมอบ และความเสี่ยงในการล็อกสเปก",text:"ตรวจร่างขอบเขตของงาน (TOR) ต่อไปนี้: [TOR] โดยตรวจความชัดเจนของวัตถุประสงค์ คุณลักษณะเฉพาะ ความเป็นกลาง เกณฑ์ตรวจรับ ระยะเวลา การรับประกัน เงื่อนไขที่อาจจำกัดการแข่งขัน และข้อมูลที่ควรแก้ไข"},
 {id:7,category:"บุคคล",title:"ร่างคำสั่งแต่งตั้งคณะทำงาน",desc:"จัดองค์ประกอบ หน้าที่ อำนาจ และข้อกำหนดการรายงานผล",text:"ร่างคำสั่ง [หน่วยงาน] เรื่องแต่งตั้งคณะทำงาน [ชื่อคณะ] โดยมีรายชื่อ [รายชื่อ] มีหน้าที่ [หน้าที่] ระบุอำนาจประสานงาน การรายงานผล วันที่มีผล และข้อความปิดท้ายตามรูปแบบราชการ"},
 {id:8,category:"บริการประชาชน",title:"ตอบข้อร้องเรียนประชาชน",desc:"ตอบอย่างสุภาพ ชี้แจงข้อเท็จจริง ขั้นตอน และกรอบเวลา",text:"ร่างหนังสือตอบข้อร้องเรียนเรื่อง [เรื่อง] จากข้อมูล [ข้อเท็จจริง] ให้มีคำขอบคุณ การรับทราบประเด็น ผลการตรวจสอบ ขั้นตอนที่ดำเนินการ กรอบเวลา ช่องทางติดตาม และถ้อยคำสุภาพ โดยไม่เปิดเผยข้อมูลส่วนบุคคลเกินจำเป็น"},
 {id:9,category:"แผนงาน",title:"สร้างโครงร่างโครงการ",desc:"ออกแบบหลักการ เหตุผล วัตถุประสงค์ กิจกรรม งบประมาณ และตัวชี้วัด",text:"จัดทำโครงร่างโครงการขององค์กรปกครองส่วนท้องถิ่นเรื่อง [ชื่อ] จากปัญหา [ปัญหา] ประกอบด้วยหลักการและเหตุผล วัตถุประสงค์ เป้าหมาย กิจกรรม ระยะเวลา สถานที่ งบประมาณ ผู้รับผิดชอบ ตัวชี้วัด ผลที่คาดว่าจะได้รับ และความเสี่ยง"},
 {id:10,category:"ข้อมูล",title:"สรุปข้อมูลเสนอผู้บริหาร 1 หน้า",desc:"ย่อข้อมูลจำนวนมากให้เหลือประเด็นตัดสินใจและทางเลือก",text:"สรุปข้อมูลต่อไปนี้เป็น Executive Brief ภาษาไทยไม่เกิน 1 หน้า: [ข้อมูล] แยกสถานการณ์ ประเด็นสำคัญ ผลกระทบ ทางเลือก 2-3 ทาง ความเสี่ยง และข้อเสนอแนะเพื่อการตัดสินใจ"},
 {id:11,category:"ประชาคม",title:"ออกแบบคำถามประชาคม",desc:"สร้างคำถามที่เป็นกลางและช่วยให้ได้ข้อมูลเพื่อจัดทำแผน",text:"ออกแบบชุดคำถามสำหรับเวทีประชาคมเรื่อง [หัวข้อ] จำนวน 10-15 ข้อ ครอบคลุมปัญหา ความต้องการ ลำดับความสำคัญ กลุ่มที่ได้รับผลกระทบ ทรัพยากรในพื้นที่ และข้อเสนอของประชาชน ใช้ถ้อยคำเป็นกลาง"},
 {id:12,category:"ตรวจทาน",title:"ตรวจภาษาราชการและความครบถ้วน",desc:"ตรวจคำผิด ความชัดเจน ความสอดคล้อง และจุดที่ต้องยืนยัน",text:"ตรวจเอกสารราชการต่อไปนี้: [เอกสาร] โดยแสดง 1) คำผิด/ไวยากรณ์ 2) ประโยคกำกวม 3) ข้อมูลไม่สอดคล้อง 4) ส่วนประกอบที่ขาด 5) ข้อความที่ควรระวัง 6) ฉบับปรับแก้ โดยห้ามเปลี่ยนสาระสำคัญ"}
]; 
const customPrompts = JSON.parse(localStorage.getItem("lg-custom-prompts") || "[]");
const prompts = [...builtInPrompts, ...customPrompts];

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const favorites = new Set(JSON.parse(localStorage.getItem("lg-favorites") || "[]"));

function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),1800)}
function copyText(text){navigator.clipboard?.writeText(text).then(()=>toast("คัดลอกแล้ว")).catch(()=>{const t=document.createElement("textarea");t.value=text;document.body.appendChild(t);t.select();document.execCommand("copy");t.remove();toast("คัดลอกแล้ว")})}
function saveFavorites(){localStorage.setItem("lg-favorites",JSON.stringify([...favorites]));updateCounts()}
function updateCounts(){$("#promptCount").textContent=prompts.length;$("#favoriteCount").textContent=favorites.size}
function promptCard(p){
 const fav=favorites.has(p.id);
 return `<article class="prompt-card"><span class="badge">${p.category}</span><h4>${p.title}</h4><p>${p.desc}</p><div class="card-actions"><button class="secondary copy-prompt" data-id="${p.id}">คัดลอก</button><button class="secondary fav-prompt" data-id="${p.id}">${fav?"★ บันทึกแล้ว":"☆ บันทึก"}</button></div></article>`
}
function bindCards(){
 $$(".copy-prompt").forEach(b=>b.onclick=()=>copyText(prompts.find(p=>p.id==b.dataset.id).text));
 $$(".fav-prompt").forEach(b=>b.onclick=()=>{const id=+b.dataset.id;favorites.has(id)?favorites.delete(id):favorites.add(id);saveFavorites();renderPrompts();renderFavorites()})
}
function renderPrompts(){
 const q=$("#searchInput").value.trim().toLowerCase(), cat=$("#categoryFilter").value;
 const list=prompts.filter(p=>(!cat||p.category===cat)&&(!q||`${p.title} ${p.desc} ${p.text}`.toLowerCase().includes(q)));
 $("#promptGrid").innerHTML=list.length?list.map(promptCard).join(""):`<p>ไม่พบ Prompt ที่ตรงกับคำค้น</p>`;bindCards()
}
function renderFavorites(){
 const list=prompts.filter(p=>favorites.has(p.id));
 $("#favoriteGrid").innerHTML=list.length?list.map(promptCard).join(""):`<p>ยังไม่มีรายการโปรด เปิดคลัง Prompt แล้วกด “☆ บันทึก”</p>`;bindCards()
}
function showView(id){
 $$(".view").forEach(v=>v.classList.toggle("active",v.id===id));$$(".nav-item").forEach(n=>n.classList.toggle("active",n.dataset.view===id));
 const titles={home:["ภาพรวม","เครื่องมือช่วยงานราชการและงานท้องถิ่นในที่เดียว"],prompts:["คลัง Prompt","ค้นหา ปรับใช้ และบันทึก Prompt ที่ใช้บ่อย"],documents:["ร่างหนังสือราชการ","สร้างแบบร่างจากข้อมูลที่คุณกรอก"],legal:["ผู้ช่วยงานกฎหมาย","จัดโครงข้อเท็จจริง ประเด็นกฎหมาย และความเสี่ยง"],favorites:["รายการโปรด","Prompt ที่บันทึกไว้บนอุปกรณ์นี้"],settings:["ตั้งค่าหน่วยงาน","บันทึกข้อมูลสำหรับใช้ในเอกสารและสำรองข้อมูล"]};
 $("#pageTitle").textContent=titles[id][0];$("#pageSubtitle").textContent=titles[id][1];$("#sidebar").classList.remove("open");window.scrollTo({top:0,behavior:"smooth"})
}
$$(".nav-item").forEach(b=>b.onclick=()=>showView(b.dataset.view));
$$("[data-go]").forEach(b=>b.onclick=()=>showView(b.dataset.go));
$("#menuBtn").onclick=()=>$("#sidebar").classList.toggle("open");
$("#themeBtn").onclick=()=>{document.body.classList.toggle("dark");localStorage.setItem("lg-dark",document.body.classList.contains("dark")?"1":"0")};
if(localStorage.getItem("lg-dark")==="1")document.body.classList.add("dark");

const cats=[...new Set(prompts.map(p=>p.category))].sort();
$("#categoryFilter").innerHTML+=cats.map(c=>`<option>${c}</option>`).join("");
$("#searchInput").oninput=renderPrompts;$("#categoryFilter").onchange=renderPrompts;


const settings = JSON.parse(localStorage.getItem("lg-settings") || "{}");
$("#settingAgency").value=settings.agency||"";
$("#settingAddress").value=settings.address||"";
$("#settingSigner").value=settings.signer||"";
$("#settingPosition").value=settings.position||"";
$("#settingContact").value=settings.contact||"";
if(settings.agency && !$("#agency").value) $("#agency").value=settings.agency;

$("#settingsForm").onsubmit=e=>{
 e.preventDefault();
 const data={agency:$("#settingAgency").value.trim(),address:$("#settingAddress").value.trim(),signer:$("#settingSigner").value.trim(),position:$("#settingPosition").value.trim(),contact:$("#settingContact").value.trim()};
 localStorage.setItem("lg-settings",JSON.stringify(data));
 if(data.agency) $("#agency").value=data.agency;
 toast("บันทึกการตั้งค่าแล้ว");
};

$("#customPromptForm").onsubmit=e=>{
 e.preventDefault();
 const nextId=Math.max(1000,...prompts.map(p=>p.id))+1;
 const p={id:nextId,category:$("#customCategory").value.trim(),title:$("#customTitle").value.trim(),desc:"Prompt ที่เพิ่มโดยหน่วยงาน",text:$("#customText").value.trim()};
 customPrompts.push(p);prompts.push(p);
 localStorage.setItem("lg-custom-prompts",JSON.stringify(customPrompts));
 if(![...$("#categoryFilter").options].some(o=>o.value===p.category)){
   const o=document.createElement("option");o.value=p.category;o.textContent=p.category;$("#categoryFilter").appendChild(o);
 }
 e.target.reset();updateCounts();renderPrompts();toast("เพิ่ม Prompt แล้ว");
};

$("#exportData").onclick=()=>{
 const data={version:"1.2",exportedAt:new Date().toISOString(),settings:JSON.parse(localStorage.getItem("lg-settings")||"{}"),favorites:[...favorites],customPrompts,document:localStorage.getItem("lg-last-document")||"",drafts:JSON.parse(localStorage.getItem("lg-document-drafts")||"[]")};
 const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});
 const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="ข้อมูลสำรอง-ai-ผู้ช่วยอปท.json";a.click();URL.revokeObjectURL(a.href);
};
$("#importData").onchange=async e=>{
 const f=e.target.files[0];if(!f)return;
 try{
  const data=JSON.parse(await f.text());
  if(data.settings)localStorage.setItem("lg-settings",JSON.stringify(data.settings));
  if(data.favorites)localStorage.setItem("lg-favorites",JSON.stringify(data.favorites));
  if(data.customPrompts)localStorage.setItem("lg-custom-prompts",JSON.stringify(data.customPrompts));
  if(data.document)localStorage.setItem("lg-last-document",data.document);
  if(data.drafts)localStorage.setItem("lg-document-drafts",JSON.stringify(data.drafts));
  alert("นำเข้าข้อมูลแล้ว ระบบจะโหลดหน้าใหม่");location.reload();
 }catch(err){alert("ไฟล์สำรองไม่ถูกต้อง")}
};
$("#clearData").onclick=()=>{
 if(confirm("ต้องการล้างการตั้งค่า รายการโปรด แบบร่าง และ Prompt ที่เพิ่มเองทั้งหมดหรือไม่?")){
  ["lg-settings","lg-favorites","lg-custom-prompts","lg-last-document","lg-document-drafts","lg-autosave-document"].forEach(k=>localStorage.removeItem(k));location.reload();
 }
};

$("#documentForm").onsubmit=e=>{
 e.preventDefault();
 const type=$("#docType").value, agency=$("#agency").value.trim(), docNumber=$("#docNumber").value.trim()||"................................", docDate=$("#docDate").value||"................................", subject=$("#subject").value.trim(), recipient=$("#recipient").value.trim()||"ผู้บังคับบัญชา", attachments=$("#attachments").value.trim(), facts=$("#facts").value.trim(), request=$("#request").value.trim()||"จึงเรียนมาเพื่อโปรดพิจารณาสั่งการตามที่เห็นสมควร"; const st=JSON.parse(localStorage.getItem("lg-settings")||"{}"); const signer=st.signer||"................................................"; const position=st.position||"................................................";
 let out="";
 if(type==="บันทึกข้อความ") out=`บันทึกข้อความ

ส่วนราชการ  ${agency}
ที่  ${docNumber}        วันที่  ${docDate}
เรื่อง  ${subject}
เรียน  ${recipient}

1. เรื่องเดิม / ความเป็นมา
${facts}

2. ข้อพิจารณา
จากข้อเท็จจริงข้างต้น เห็นควรตรวจสอบความครบถ้วนของเอกสาร อำนาจหน้าที่ งบประมาณ และระเบียบที่เกี่ยวข้องก่อนดำเนินการ ทั้งนี้ ให้ยืนยันเลขที่หนังสือ วันที่ ชื่อบุคคล และข้อกฎหมายกับเอกสารต้นฉบับ

3. ข้อเสนอ
${request}

ลงชื่อ ................................................
(${signer})\nตำแหน่ง ${position}`;
 else if(type==="หนังสือภายนอก") out=`ที่ ${docNumber}
${agency}
วันที่ ${docDate}

เรื่อง  ${subject}
เรียน  ${recipient}

สิ่งที่ส่งมาด้วย  ${attachments||"(ถ้ามี)"}

ด้วย ${facts}

ในการนี้ ${request}

จึงเรียนมาเพื่อโปรดพิจารณา

ขอแสดงความนับถือ

(ลงชื่อ) ${signer}\nตำแหน่ง ${position}`;
 else out=`${type}
เรื่อง ${subject}

หน่วยงาน: ${agency}

หลักการและเหตุผล / ข้อเท็จจริง
${facts}

สาระสำคัญ
${request}

ทั้งนี้ ตั้งแต่วันที่ ................................ เป็นต้นไป

ประกาศ/สั่ง ณ วันที่ ................................

ลงชื่อ ${signer}\nตำแหน่ง ${position}`;
 $("#documentOutput").textContent=out;localStorage.setItem("lg-last-document",out);toast("สร้างแบบร่างแล้ว")
};
$("#copyDocument").onclick=()=>copyText($("#documentOutput").textContent);
$("#downloadWord").onclick=()=>{
 const text=$("#documentOutput").textContent.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\n/g,"<br>");
 const html=`<html><head><meta charset="utf-8"><style>body{font-family:"TH Sarabun New","Sarabun",sans-serif;font-size:18pt;line-height:1.5;margin:2.5cm}</style></head><body>${text}</body></html>`;
 const blob=new Blob(["\ufeff",html],{type:"application/msword"});
 const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="ร่างเอกสารราชการ.doc";a.click();URL.revokeObjectURL(a.href);
};
$("#printDocument").onclick=()=>window.print();
$("#downloadDocument").onclick=()=>{const blob=new Blob([$("#documentOutput").textContent],{type:"text/plain;charset=utf-8"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="ร่างเอกสารราชการ.txt";a.click();URL.revokeObjectURL(a.href)};

$("#legalForm").onsubmit=e=>{
 e.preventDefault();
 const topic=$("#legalTopic").value.trim(),facts=$("#legalFacts").value.trim(),question=$("#legalQuestion").value.trim();
 const out=`กรอบวิเคราะห์เรื่อง: ${topic}

1. ข้อเท็จจริงที่ได้รับ
${facts}

2. คำถามที่ต้องวิเคราะห์
${question}

3. ประเด็นที่ต้องแยกพิจารณา
- หน่วยงานหรือเจ้าหน้าที่ใดมีอำนาจหน้าที่
- มีขั้นตอนหรือเงื่อนไขตามกฎหมาย/ระเบียบใด
- มีข้อเท็จจริงส่วนใดที่ยังไม่ชัดเจน
- มีเอกสารหลักฐานใดรองรับ
- มีข้อจำกัดด้านงบประมาณ ระยะเวลา หรือการอนุมัติหรือไม่

4. กฎหมายและเอกสารที่ควรค้นเพิ่มเติม
- กฎหมายจัดตั้งและกฎหมายว่าด้วยอำนาจหน้าที่ของหน่วยงาน
- ระเบียบหรือหนังสือสั่งการเฉพาะเรื่อง
- มติหรือคำวินิจฉัยที่เกี่ยวข้อง
- คำสั่งมอบอำนาจและโครงสร้างการบังคับบัญชา
- เอกสารข้อเท็จจริงต้นฉบับ

5. ความเสี่ยงที่ควรตรวจ
- ดำเนินการเกินอำนาจหรือผิดขั้นตอน
- ข้อเท็จจริงไม่ครบหรือหลักฐานไม่เพียงพอ
- ผลประโยชน์ทับซ้อน / การเลือกปฏิบัติ
- การเปิดเผยข้อมูลส่วนบุคคล
- ความเสียหายด้านงบประมาณหรือความรับผิดของเจ้าหน้าที่

6. แนวทางดำเนินการเบื้องต้น
รวบรวมเอกสารและยืนยันข้อเท็จจริง จัดทำลำดับเหตุการณ์ ตรวจฐานอำนาจและขั้นตอน ขอความเห็นจากผู้รับผิดชอบด้านกฎหมายหรือหน่วยงานกำกับ และเสนอผู้มีอำนาจวินิจฉัยโดยแสดงทางเลือกพร้อมความเสี่ยง

หมายเหตุ: กรอบนี้ไม่ใช่ข้อยุติทางกฎหมาย ต้องตรวจสอบกฎหมายและระเบียบฉบับปัจจุบันก่อนใช้`;
 $("#legalOutput").textContent=out;toast("สร้างกรอบวิเคราะห์แล้ว")
};
$("#copyLegal").onclick=()=>copyText($("#legalOutput").textContent);

const DRAFT_KEY="lg-document-drafts";
let drafts=JSON.parse(localStorage.getItem(DRAFT_KEY)||"[]");
function draftFormData(){return {id:Date.now(),savedAt:new Date().toISOString(),type:$("#docType").value,agency:$("#agency").value,docNumber:$("#docNumber").value,docDate:$("#docDate").value,subject:$("#subject").value,recipient:$("#recipient").value,attachments:$("#attachments").value,facts:$("#facts").value,request:$("#request").value,output:$("#documentOutput").textContent}}
function applyDraft(d){["type","agency","docNumber","docDate","subject","recipient","attachments","facts","request"].forEach(k=>{const el=$("#"+(k==="type"?"docType":k));if(el)el.value=d[k]||""});$("#documentOutput").textContent=d.output||"";showView("documents");toast("เปิดร่างแล้ว")}
function renderDrafts(){const el=$("#draftList");if(!drafts.length){el.innerHTML="<p class=muted>ยังไม่มีร่างที่บันทึกไว้</p>";return}el.innerHTML=drafts.map(d=>`<article class="draft-item"><div><h4>${d.subject||"ร่างไม่มีชื่อ"}</h4><p>${d.type} • ${new Date(d.savedAt).toLocaleString("th-TH")}</p></div><div class="draft-item-actions"><button class="secondary mini open-draft" data-id="${d.id}">เปิด</button><button class="danger mini delete-draft" data-id="${d.id}">ลบ</button></div></article>`).join("");$$('.open-draft').forEach(b=>b.onclick=()=>applyDraft(drafts.find(d=>d.id==b.dataset.id)));$$('.delete-draft').forEach(b=>b.onclick=()=>{drafts=drafts.filter(d=>d.id!=b.dataset.id);localStorage.setItem(DRAFT_KEY,JSON.stringify(drafts));renderDrafts();toast("ลบร่างแล้ว")})}
$("#saveDraft").onclick=()=>{const d=draftFormData();if(!d.subject&&!d.facts){toast("กรอกเรื่องหรือข้อเท็จจริงก่อนบันทึก");return}drafts.unshift(d);drafts=drafts.slice(0,30);localStorage.setItem(DRAFT_KEY,JSON.stringify(drafts));renderDrafts();toast("บันทึกร่างแล้ว")};
$("#newDraft").onclick=()=>{if(confirm("เริ่มร่างใหม่และล้างข้อมูลในแบบฟอร์มหรือไม่?")){document.querySelector("#documentForm").reset();if(settings.agency)$("#agency").value=settings.agency;$("#documentOutput").textContent="กรอกข้อมูลด้านซ้าย แล้วกด “สร้างแบบร่าง”"}};
$("#clearDrafts").onclick=()=>{if(confirm("ลบร่างที่บันทึกไว้ทั้งหมดหรือไม่?")){drafts=[];localStorage.removeItem(DRAFT_KEY);renderDrafts()}};
["docType","agency","docNumber","docDate","subject","recipient","attachments","facts","request"].forEach(id=>$("#"+id)?.addEventListener("input",()=>{localStorage.setItem("lg-autosave-document",JSON.stringify(draftFormData()))}));
const auto=JSON.parse(localStorage.getItem("lg-autosave-document")||"null");if(auto&&!localStorage.getItem("lg-last-document"))applyDraft(auto);
const last=localStorage.getItem("lg-last-document");if(last)$("#documentOutput").textContent=last;renderDrafts();
updateCounts();renderPrompts();renderFavorites();
