# Smart Local Digital Platform (SLDP) v2.0 — Foundation

ชุดเริ่มต้นการพัฒนาแพลตฟอร์มดิจิทัลสำหรับองค์กรปกครองส่วนท้องถิ่น

## เป้าหมาย MVP
1. Smart Local AI
2. Document Center
3. Law Center
4. Executive Dashboard
5. Users & Roles

## โครงสร้าง
- `docs/` เอกสารสถาปัตยกรรมและ Product Backlog
- `database/` โครงสร้างฐานข้อมูลเริ่มต้น
- `api/` ข้อกำหนด API รุ่นแรก
- `frontend/` พื้นที่สำหรับ Next.js
- `backend/` พื้นที่สำหรับ Backend API
- `ai/` พื้นที่สำหรับ AI/RAG service
- `deployment/` Docker และการติดตั้ง
- `tests/` แผนและชุดทดสอบ
- `legacy/prototype-v1.2/` เว็บต้นแบบเดิมที่เก็บไว้เพื่อย้ายฟังก์ชัน

## หลักการสำคัญ
- Multi-tenant ตั้งแต่ต้น
- แยกข้อมูลแต่ละหน่วยงาน
- RBAC และ Audit Log
- AI ต้องแสดงแหล่งอ้างอิงเมื่อใช้ข้อมูลกฎหมายหรือเอกสาร
- ไม่ฝัง API key ใน Frontend
